<div class="slider-content">
    <h6 class="testimonials-title"><?php echo ''.$item['list_name']; ?></h6>
    <span class="average-rating">
        <span class="jws-star-rating"><span class="jws-star-rated" style="width:100%"></span></span>
    </span>   
    <div class="testimonials_description"><?php echo ''.$item['list_description']; ?></div>   
</div>

