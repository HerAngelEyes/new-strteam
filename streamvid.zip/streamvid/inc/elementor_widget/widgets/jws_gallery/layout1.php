 <div class="gallery-image">
     <a <?php echo ''.$this->get_render_attribute_string($link_key); ?>>
        <?php 
          echo !empty($image) ? $image : ''; 
     ?>
    </a>    
</div>