 <div class="jws_video_popup<?php echo esc_attr(' video-'.$settings['skins']); ?>">
        <div class="jws_video_popup_inner">
              <a href="<?php echo esc_url($url); ?>">
                   <span class="video_icon">
                        <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] );  ?>
                   </span>
              </a>
        </div>            
</div>