<a href="<?php echo esc_url(get_term_link($category->slug, $settings['post_type'])); ?>">
      <span><?php echo esc_html($category->name); ?></span> 
</a>