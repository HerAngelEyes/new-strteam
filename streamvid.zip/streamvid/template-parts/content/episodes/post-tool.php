<div class="jws-tool">

    <?php if(function_exists('jws_like_button')) jws_like_button('tv_shows',$args); ?>
    <?php if(function_exists('jws_watchlist_button')) jws_watchlist_button($args); ?>
    <?php if(function_exists('jws_share_button')) jws_share_button(); ?>
</div>