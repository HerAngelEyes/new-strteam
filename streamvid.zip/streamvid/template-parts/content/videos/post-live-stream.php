<?php 
    jws_streamvid()->get()->live_videos->stream_frontend(); 
?>

