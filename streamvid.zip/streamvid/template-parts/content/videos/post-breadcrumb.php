<?php 
 echo '<div class="jws-breadcrumb">'.jws_page_breadcrumb('<span class="delimiter">/</span>').'</div>';
?>