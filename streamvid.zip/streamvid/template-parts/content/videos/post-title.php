<?php 
   
    echo '<h1 class="jws-title h3">'.get_the_title().'</h1>'; 
?>

